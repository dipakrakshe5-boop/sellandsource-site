# Sell & Source Website

This is the official website for Sell & Source.

## Pages
- Home (index.html)
- About (about.html)
- Vendors (vendors.html)
- Contact (contact.html)

## Deployment
1. Upload these files to a GitHub repo.
2. Connect the repo to Netlify.
3. Done!

Forms are powered by [Formspree](https://formspree.io).
